<?php 
	$base_url = Yii::getAlias('@web');
 ?>
<!DOCTYPE html>
<html>
<div class="jumbotron text-center">
	<h1 class="display-3">No Item Added!</h1>
	<p class="lead">
		<a class="btn btn-danger btn-sm" href="<?= $base_url;?>/index.php?r=allotment" role="button">Check Availability</a>
	</p>
</div>
</html>