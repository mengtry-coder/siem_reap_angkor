<div id="" style="background-color:#ffffff;padding:0px">
    <table style="font-family:'Open Sans',sans-serif;font-size:12px;margin:0px" width="100%" border="0" cellspacing="0">
        <tbody>
            <tr>
                <td>
                    <p style="font-size:20px">Demo</p>
                </td>
            </tr>
            <tr>
                <td style="background-color:#eeeeee;padding:15px 15px 15px 15px;border-bottom-left-radius:0;border-bottom-right-radius:0" valign="top">
                    <table width="100%" border="0" cellpadding="0">
                        <tbody>
                            <tr valign="top">
                                <td width="65%">
                                    <span style="font-size:12px">
                                        <strong>Thank you, ប្រាក់! Your booking is confirmed</strong>
                                    </span>
                                </td>
                                <td style="font-size:12px" width="35%">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tbody>
                                            <tr>
                                                <td align="right">
                                                    <strong>Booking number:</strong> WE576C
                                                    <a href="tel:1586500943" target="_blank">1586500943</a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td style="background-color:#f8f8f8;padding:0 15px 15px 15px;border-top-left-radius:0;border-top-right-radius:0" valign="top">
                    <table width="100%" border="0" cellpadding="0">
                        <tbody>
                            <tr valign="top">
                                <td width="65%">
                                    <ul style="padding:15px 0 0 15px;margin:0">
                                        <li style="line-height:20px;padding:0;margin:0">For booking enquires, cancellations or amendments please contact us directly at 
                                            <a href="mailto:bunchhay@eocambo.com" target="_blank">bunchhay@eocambo.com</a> or 
                                            <a href="tel:+85569955179" target="_blank">+855 69 955 179</a>, 
                                            <a href="tel:+85577466082" target="_blank">+855 77 466 082</a>.
                                        </li>
                                    </ul>
                                </td>
                                <td style="font-size:12px" width="35%">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tbody>
                                            <tr>
                                                <td align="right">&nbsp;</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <div style="border-bottom:2px solid #eeeeee;padding-bottom:8px;font-size:14px;margin-top:20px">
                        <strong>Your Booking</strong>
                    </div>
                    <table style="border-bottom:2px solid #eeeeee;padding-bottom:8px;margin-top:8px" width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tbody>
                            <tr>
                                <td style="padding:1px 10px 1px 20px" valign="top" width="20%">
                                    <strong>Guest:</strong>
                                </td>
                                <td style="padding:1px 20px" width="80%">ប្រាក់ ស៊ីវិឆ័យ</td>
                            </tr>
                            <tr>
                                <td style="padding:1px 10px 1px 20px" valign="top" width="20%">
                                    <strong>Details:</strong>
                                </td>
                                <td style="padding:1px 0px 1px 20px" width="80%">
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tbody>
                                            <tr>
                                                <td width="75%">1 DOUBLE ROOM, 2 adults  included in price</td>
                                                <td width="25%" valign="top" align="right" style="padding:1px 15px">US$ 110.00
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:1px 10px 1px 20px" width="20%">
                                    <strong>Check-in:</strong>
                                </td>
                                <td style="padding:1px 20px" width="80%">Friday, April 10, 2020 from 14:00
                                </td>
                            </tr>
                            <tr>
                                <td style="padding:1px 10px 1px 20px" width="20%">
                                    <strong>Check-out:</strong>
                                </td>
                                <td style="padding:1px 20px" width="80%">Saturday, April 11, 2020 until 12:00</td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <div style="border-bottom:2px solid #eeeeee;padding-bottom:8px;font-size:14px;margin-top:20px">
                        <strong>Additional Details</strong>
                    </div>
                    <table style="border-bottom:2px solid #eeeeee;padding-bottom:8px;margin-top:8px" width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tbody>
                            <tr>
                                <td>
                                    <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                        <tbody>
                                            <tr>
                                                <td width="20%" style="padding:1px 10px 1px 20px">
                                                    <strong>Additional comments:</strong>
                                                </td>
                                                <td width="80%" style="padding:1px 20px">Booking</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <div style="border-bottom:2px solid #eeeeee;padding-bottom:8px;font-size:14px;margin-top:20px">
                        <strong>Payment Details</strong>
                    </div>
                    <table style="border-bottom:2px solid #eeeeee;padding-bottom:8px;margin-top:8px" width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tbody>
                            <tr>
                                <td style="padding:1px 20px" width="50%">
                                    <strong>Booking value:</strong>
                                </td>
                                <td style="padding:1px 15px" align="right" width="50">US$ 110.00</td>
                            </tr>
                            <tr>
                                <td style="padding:1px 20px"><strong>To be processed via Visa:</strong></td>
                                <td style="padding:1px 15px" align="right">US$ 110.00</td>
                            </tr>
                            <tr>
                                <td style="padding:1px 20px"> 
                                    <span style="font-size:11px">Prices include 10% Test.</span>
                                </td>
                                <td style="padding:1px 15px;vertical-align:top" align="right"></td>
                            </tr>
                            <tr>
                                <td colspan="2"></td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td>
                    <div style="font-size:14px;margin-top:20px"><strong>Booking Policies</strong>
                    </div>
                    <table style="margin-top:8px" width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tbody>
                            <tr>
                                <td>
                                    <table width="100%" border="0" cellpadding="0" cellspacing="0">
                                        <tbody>
                                            <tr>
                                                <td style="border-bottom:2px solid #eeeeee;border-top:2px solid #eeeeee;padding:10px 20px!important">
                                                    <div style="padding-bottom:5px">
                                                        <strong>DOUBLE ROOM - DOUBLE ROOM</strong>
                                                    </div>
                                                    <span style="font-size:11px">
                                                        <strong>Cancellation:</strong> <br>
                                                        <strong>Payment:   </strong>Full booking item amount will be charged.<br>
                                                    </span>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
        </tbody>
    </table>
</div>