<blockquote style="margin:0 0 0 0ex;border-left:0px;padding-left:0ex">
	<div dir="ltr">
		<table width="100%" border="0" cellspacing="0" style="font-family:&quot;Open Sans&quot;,sans-serif;font-size:12px;margin:0px">
			<tbody>
				<tr>
					<td>
						<p style="font-size:20px">Demo</p>
					</td>
				</tr>
				<tr>
					<td valign="top" style="background-color:rgb(238,238,238);padding:15px;border-bottom-left-radius:0px;border-bottom-right-radius:0px">
						<table width="100%" border="0" cellpadding="0">
							<tbody>
								<tr valign="top">
									<td width="65%">
										<strong>CONGRATULATIONS! You’ve received a new booking.</strong>
									</td>
									<td width="35%">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tbody>
												<tr>
													<td align="right">
														<strong>Booking number:</strong>
														<span>&nbsp;</span>WE576C
														<a href="tel:1586500943" target="_blank">1586500943</a>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td valign="top" style="background-color:rgb(248,248,248);padding:0px 15px 15px;border-top-left-radius:0px;border-top-right-radius:0px">
						<table width="100%" border="0" cellpadding="0">
							<tbody>
								<tr valign="top">
									<td width="65%">
										<ul style="padding:15px 0px 0px 15px;margin:0px">
											<li style="line-height:20px;padding:0px;margin:0px">We've sent the confirmation email to the guest.
											</li>
											<li style="line-height:20px;padding:0px;margin:0px">For booking enquiries, cancellations or amendments the guest has been instructed to contact you directly.</li>
										</ul>
									</td>
									<td width="35%" style="vertical-align:bottom">
										<table width="100%" border="0" cellspacing="0" cellpadding="0">
											<tbody>
												<tr>
													<td align="right" style="padding-top:10px">
														<a href="" style="text-decoration-line:none;background-color:rgb(71,146,215);border:0px solid rgb(41,117,188);display:inline-block;line-height:normal;padding:0.5rem 1rem 0.5625rem;text-align:center;color:rgb(255,255,255)" target="_blank" >VIEW BOOKING</a>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<div style="border-bottom:2px solid rgb(238,238,238);padding-bottom:8px;font-size:14px;margin-top:20px">
							<strong>YOUR BOOKING</strong>
						</div>
						<table width="100%" border="0" cellspacing="0" cellpadding="0" style="padding-bottom:8px;margin-top:8px">
							<tbody>
								<tr>
									<td valign="top" width="20%" style="padding:1px 10px 1px 20px">
										<strong>Guest:</strong>
									</td>
									<td width="80%" style="padding:1px 20px">ប្រាក់ ស៊ីវិឆ័យ (Cambodia)</td>
								</tr>
								<tr>
									<td valign="top" width="20%" style="padding:1px 20px">
										<strong>&nbsp;</strong>
									</td>
									<td width="80%" style="padding:1px 20px">
										<a href="mailto:bunchhayyoeurn096@gmail.com" title="mailto:bunchhayyoeurn096@gmail.com" target="_blank">bunchhayyoeurn096@gmail.com</a>
									</td>
								</tr>
								<tr>
									<td valign="top" width="20%" style="padding:1px 20px">
										<strong>&nbsp;</strong>
									</td>
									<td width="80%" style="padding:1px 20px">
										<a href="tel:+85577466082" target="_blank">+855 77 466 082</a>
									</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 10px 1px 20px">
										<strong>Check-in:</strong>
									</td>
									<td width="80%" style="padding:1px 20px">Friday, April 10, 2020 from 14:00</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 10px 1px 20px">
										<strong>Check-out:</strong>
									</td>
									<td width="80%" style="padding:1px 20px">Saturday, April 11, 2020 until 12:00</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 10px 1px 20px;vertical-align:top">
										<strong>Rooms booked:</strong>
									</td>
									<td width="80%" style="padding:1px 20px">1 DOUBLE ROOM - DOUBLE ROOM</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 10px 1px 20px">
										<strong>Booked on:</strong>
									</td>
									<td width="80%" style="padding:1px 20px">Friday, April 10, 2020</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 10px 1px 20px">
										<strong>Source:</strong>
									</td>
									<td width="80%" style="padding:1px 20px">Website (
										<a href="" title="" target="_blank" >booking details</a>)
									</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 10px 1px 20px">
										<strong>Total room cost:</strong>
									</td>
									<td width="80%" style="padding:1px 20px">US$ 110.00</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 10px 1px 20px">
										<strong>Grand total cost:</strong>
									</td>
									<td width="80%" style="padding:1px 20px">
										<strong>US$ 110.00
											<span>&nbsp;</span>
										</strong>
									</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 10px 1px 20px">
										<strong>Balance due now:</strong>
									</td>
									<td width="80%" style="padding:1px 20px">US$ 110.00</td>
								</tr>
								<tr>
									<td valign="top" width="20%" style="padding:1px 20px">
										<strong>&nbsp;</strong>
									</td>
									<td width="80%" style="padding:1px 20px">
										<strong>Prices include 10% Test.</strong>
									</td>
								</tr>
								<tr>
									<td valign="top" width="20%" style="padding:1px 20px">
										<strong>&nbsp;</strong>
									</td>
									<td width="80%" style="padding:1px 20px">You should charge the guest's credit card in accordance with the deposit and final payment conditions detailed above. Login to
										<span>&nbsp;</span>
										<a href="" title="" target="_blank" >SAA extranet</a>
										<span>&nbsp;</span>to view credit card details for this guest. This is an Internet booking, and as such, there is a very small risk of fraud. It is your responsibility to ask for Photo ID at check-in to verify the identity of the guest.
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<div style="border-bottom:2px solid rgb(238,238,238);padding-bottom:8px;font-size:14px;margin-top:20px">
							<strong>ROOM DETAILS</strong>
						</div>
						<div style="background-color:rgb(238,238,238);padding:5px;font-size:14px;margin-top:20px">
							<b>DOUBLE ROOM - DOUBLE ROOM</b>
						</div>
						<table border="0" cellpadding="0" cellspacing="0" width="100%" style="padding-bottom:8px;margin-top:8px">
							<tbody>
								<tr>
									<td width="20%" style="padding:1px 20px;vertical-align:top">
										<strong>Number of rooms:</strong>
									</td>
									<td align="80%" width="50" style="padding:1px 15px">1</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 20px;vertical-align:top">
										<strong>Number of guests:</strong>
									</td>
									<td align="80%" width="50" style="padding:1px 15px">2 adults</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 20px">
										<strong>Total price:</strong>
									</td>
									<td align="80%" width="50" style="padding:1px 15px">US$ 110.00
									</td>
								</tr>
								<tr>
									<td width="20%" style="padding:1px 20px;vertical-align:top">
										<strong>Booking policies:</strong>
									</td>
									<td width="80%" style="padding:1px 15px">+
										<span>&nbsp;</span>
									</td>
								</tr>
								<tr>
									<td width="20%" valign="top" style="padding:1px 20px">
										<strong>&nbsp;</strong>
									</td>
									<td width="80%" style="padding:1px 15px">+ Payment: Full booking item amount will be charged.
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td>
						<div style="border-bottom:2px solid rgb(238,238,238);padding-bottom:8px;font-size:14px;margin-top:20px">
							<strong>EXTRA INFO</strong>
						</div>
						<table width="100%" border="0" cellspacing="0" cellpadding="0" style="padding-bottom:8px;margin-top:8px">
							<tbody>
								<tr>
									<td width="20%" style="padding:1px 20px;vertical-align:top">
										<strong>Remarks:</strong>
									</td>
									<td width="80%" style="padding:1px 15px">Booking</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</blockquote>