
<!-- Client --><!-- 
<div id=":md" class="ii gt">
	<div id=":mc" class="a3s aXjCH msg-1389475665552822997">
		<div style="color:#222;font-family:'Helvetica','Arial',sans-serif;font-size:14px;font-weight:400;line-height:19px;margin:0;min-width:100%;padding:0;text-align:left;width:100%!important">
			<div class="adM"> </div>
			<table bgcolor="#FFFFFF" style="border-collapse:collapse;border-spacing:0;color:#222;font-family:'Helvetica','Arial',sans-serif;font-size:14px;font-weight:400;height:100%;line-height:19px;margin:0;padding:0;text-align:left;vertical-align:top;width:100%">
				<tbody>
					<tr style="padding:0;text-align:left;vertical-align:top">
						<td align="center" style="border-collapse:collapse!important;color:#222;font-family:'Helvetica','Arial',sans-serif;font-size:14px;font-weight:400;line-height:19px;margin:0;padding:0;text-align:center;vertical-align:top;word-break:break-word">
							<table bgcolor="#FFFFFF" style="border-collapse:collapse;border-spacing:0;margin:0 auto;padding:0;text-align:inherit;vertical-align:top;width:580px">
								<tbody>
									<tr>
										<td height="16" style="height:16px"></td>
									</tr>
									<tr style="padding:0;text-align:left;vertical-align:top">
										<td align="left" style="border-collapse:collapse!important;color:#222;font-family:'Helvetica','Arial',sans-serif;font-size:14px;font-weight:400;line-height:19px;margin:0;padding:0;text-align:left;vertical-align:top;width:100%;word-break:break-word">
											<img align="left" height="56" src="../web/img/fav.png" style="clear:both;display:inline;float:none;height:70px!important;max-width:100%;outline:none;text-decoration:none;width:auto" class="CToWUd">
										</td>
									</tr>
									<tr>
										<td height="32" style="height:32px"></td>
									</tr>
								</tbody>
							</table>
							<table style="border-collapse:collapse;border-spacing:0;margin:0 auto;padding:0;text-align:inherit;vertical-align:top;width:580px">
								<tbody>
									<tr style="padding:0;text-align:left;vertical-align:top">
										<td style="border-collapse:collapse!important;color:#1a2b49;font-family:'GT Eesti',Arial,sans-serif;font-size:28px!important;font-weight:500!important;line-height:42px!important;margin:0;padding:0;text-align:left;vertical-align:top;word-break:break-word">Incredible travel inspiration is a click away</td></tr><tr><td height="16" style="height:16px">
										</td>
									</tr>
									<tr style="padding:0;text-align:left;vertical-align:top">
										<td style="border-collapse:collapse!important;color:#1a2b49;font-family:'GT Eesti',Arial,sans-serif;font-size:16px!important;font-weight:400!important;line-height:24px!important;margin:0;padding:0;text-align:left;vertical-align:top;word-break:break-word">Hi there,<br>
											<br>Thanks for signing up to receive SAA Traveler.
											<br>Please click below to confirm your email address and start receiving the latest travel trends, tips, and the best things to do in destinations around the world.
										</td>
									</tr>
									<tr>
										<td height="32" style="height:32px"></td>
									</tr>
									<tr style="padding:0;text-align:left;vertical-align:top">
										<td align="center" style="border-collapse:collapse!important;color:#222;font-family:'Helvetica','Arial',sans-serif;font-size:14px;font-weight:400;line-height:19px;margin:0;padding:0;text-align:center;vertical-align:top;word-break:break-word"> 
											<a height="40" href="" style="background-color:#1593ff;border-radius:26px;color:#fff;display:inline-block;font-family:'GT Eesti',Arial,sans-serif;font-size:16px!important;font-weight:500!important;line-height:20px!important;padding:10px 48px;text-decoration:none" target="_blank">Confirm </a></td></tr><tr><td height="32" style="height:32px">	
										</td>
									</tr>
									<tr style="padding:0;text-align:left;vertical-align:top">
										<td style="border-collapse:collapse!important;color:#1a2b49;font-family:'GT Eesti',Arial,sans-serif;font-size:16px!important;font-weight:400!important;line-height:24px!important;margin:0;padding:0;text-align:left;vertical-align:top;word-break:break-word">Best regards,
											<br>The SAA Team
										</td>
									</tr>
									<tr>
										<td height="16" style="height:16px"></td>
									</tr>
									<tr style="padding:0;text-align:left;vertical-align:top">
										<td style="border-collapse:collapse!important;color:#b1b6bf!important;font-family:'GT Eesti',Arial,sans-serif;font-size:14px!important;font-weight:400!important;line-height:18px!important;margin:0;padding:0;text-align:left;vertical-align:top;word-break:break-word">If you have trouble viewing the above link, please copy the following web address into your browser's address bar:<a style="text-decoration:none;color:#1593ff;font-weight:500" href="http://siemreap-angkor.com/frontend/web/index.php?r=tour-category%2Findex" target="_blank">http://siemreap-angkor.com/web/index.php?r=tour-category%2Findex</a>
										</td>
									</tr>
									<tr>
										<td height="32" style="height:32px"></td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div> -->


