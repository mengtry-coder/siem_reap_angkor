<?php
	$this->title = 'Gallery';
	$gallery_image = \backend\models\GalleryImage::find()->all();
	$gallery_title = \backend\models\Gallery::find()->all();

 ?>
 <style type="text/css">
	@import url(https://fonts.googleapis.com/css?family=Raleway:400,800);
	.wrap_gallery p {
		font-size: 35px;
		font-family: Raleway;
		text-transform: uppercase;
		width: 21%;
		border-bottom: 5px solid #f1f1f1;
		margin: 1.66%;
	}
	.wrap_gallery img {
		width: 100%;
	    float: left;
	    object-fit: cover;
	    height: 400px;
	    margin-top: 28px;
	    /*-webkit-filter: grayscale(100%); /* Safari 6.0 - 9.0 */
  		/*filter: grayscale(100%);*/
	}
	.tab-title{
		cursor: pointer;
	}
	@media only screen and (max-width: 600px) {
		.wrap_gallery p {
			font-size: 20px;
			width: 47%;
			margin-top: 10px;
		}
	}
</style>
<div class="container-fluid">
	<div class="wrap_gallery">
		<p>Tour Gallery</p>
		<div class="container-fluid">
			<div class="row">
				<div class= "col-lg-12">
	                <ul class="nav nav-tabs">
	                	<li class="active all-img"><a data-toggle="tab" href="all">View All</a></li>
	                    <?php
	                    $i = 0;
	                    	foreach ($gallery_title as $row){
	                    		$i++;
	                    	?>
								<li><a data-toggle="tab" class= "tab-content tab-title" id= "<?=$row->id ;?>" value= "<?=$row->id ;?>"><?= $row->name;?></a></li>
                    		<?php
		                    	}
		                     ?>
	                </ul>   
                	<!-- content -->
	                <div class="tab-content">
						<div id="all" class="tab-pane fade in active">
							<div class= "row" id= "gallery-more">
                            <?php
                            	$gallery_image = \backend\models\GalleryImage::find()->limit(18)->all();
								foreach ($gallery_image as $row) {
							?>
                            	<div class="col-lg-3">
									<img src="<?= $row->file_path.$row->file_name?>" alt="">
                            	</div>
							<?php
								}
                             ?>
                    		</div>
	                    </div>
	                </div>
                </div>
			</div>
		</div>
	</div>
</div>

<?php
$base_url = Yii::getAlias('@web');
$script = <<< JS
	var base_url = "$base_url";

	$(".all-img").click(function() {
		location.reload(true);
	});

	$(".tab-title").click(function() {
	    var id = this.id;
	    $.ajax({
            url: base_url+'/index.php?r=site/dependent',
            type: 'post',
            data: {
                id: id,
                action: 'image_gallery'
            },
            success: function(response){ 
                var data = JSON.parse(response);
                console.log(data);
                var str = "";
                $.each(data,function(key,value){
                    str = str + '<div class="col-lg-3">' +
									'<img src="'+value.file_path+value.file_name+'">' +
                            	'</div>';
                });
				$( ".row .col-lg-3" ).remove();
                $("#gallery-more").append(str);
            }
        });
	});
JS;
$this->registerJS($script);
  
?>
