<?php 
	$base_url = Yii::getAlias('@web');
 ?>
<!DOCTYPE html>
<html>
<div class="jumbotron text-center">
	<h1 class="display-3">Thank You!</h1>
	<p class="lead"><strong>Please check your email</strong> for view more detail about your booking.</p>
	<hr>
	<p>
		Any Question? <a href="<?= $base_url;?>/index.php?r=site/contact">Contact us</a>
	</p>
	<p class="lead">
		<a class="btn btn-primary btn-sm" href="<?= $base_url;?>/index.php?r=site" role="button">Other Service</a>
	</p>
</div>
</html>