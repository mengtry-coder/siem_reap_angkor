<?php

use yii\helpers\Html;
use yii\helpers\Url;
use yii\bootstrap\Modal; 
use yii\grid\GridView;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use backend\models\RateRange;
use backend\models\RatePlan;
/* @var $this yii\web\View */
/* @var $searchModel backend\models\RatePlanSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Rate Plans';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    th.Sat {
    background: #ff00008f;
}
th.Sun {
    background: #ff00008f;
}
td.Sat {
    background: #79ff585e;
}
td.Sun {
    background: #79ff585e;
}
    td {
    padding: 7px;
}
    td, th { 
    border: solid black 1px;
    text-align: center;
}
#myDIV {
  height: auto;
  width: 100%;
  overflow: auto;
}
</style>
<div class="rate-plan-index">
<h5><?= Html::encode($this->title) ?></h5>
    <?php echo $this->render('_search', ['model' => $searchModel]); ?>
    <?php
        if ($searchModel->year && $searchModel->month && $searchModel->rate_set_up_id) {
        $year =  \backend\models\YearList::find()->where(['id'=>$searchModel->year])->one();
        $month =  \backend\models\MonthList::find()->where(['id'=>$searchModel->month])->one()->value;
        $item =  \backend\models\RatePlanSetUp::find()->where(['id'=>$searchModel->rate_set_up_id])->one();
        $total_days = cal_days_in_month(CAL_GREGORIAN, $month, $year->name);
        $hidden = "";
    }else{
        return $this->render('_search', ['model' => $searchModel]);
        $total_days = 0;
        $item = "";
        $hidden = "hidden";
    }
    ?>
    <div class="panel <?=$hidden;?>"> 
        <div class="panel-body">  
            <div class="row">
                <div class="col-md-12">
                    <div class="pull-right">
                        <br>
                        <?= Html::a('Update <i class="fa fa-plus-square go-right"></i>', ['rate-plan/create','id'=>$item->id, 'month'=>$month, 'year'=>$year->id], ['class' => 'btn btn-danger']) ?>
                    </div>
                </div>
            </div>
            <br>
            <!-- Row Data -->
            <div class="data-table" id="myDIV" onscroll="myFunction()">
                <table>
                    <thead>
                        <tr>
                            <th>Days</th>
                        <?php 
                            for ($i=1; $i <= $total_days ; $i++) { 
                                $day = substr(date( 'l', strtotime( $month . '/' . $i ) ), 0, 3);
                               echo "<th class= '<?= $day ;?>' colspan= 2>".$i."<br>".$day."</th>";
                            }
                        ?>
                        </tr>
                        <tr>
                            <td>Range</td>
                            <?php 
                                for ($i=1; $i <= $total_days ; $i++) { 
                                    $day = substr(date( 'l', strtotime( $month . '/' . $i ) ), 0, 3);
                                   echo "<td class= '<?= $day ;?>'>Adult</td>";
                                   echo "<td class= '<?= $day ;?>'>Child</td>";
                                }
                             ?>
                        </tr>
                        <?php
                            $rate_range = RateRange::find()->where(['month'=>$month, 'year'=>$year->id, 'rate_set_up_id'=>$item->id])->all();
                            foreach ($rate_range as $row) 
                            {
                                ?>
                                    <tr>
                                        <td><?= $row->from_person."-".$row->to_people ;?></td>
                                        <?php 
                                            for ($i = 1; $i <= $total_days; $i++) 
                                            {
                                                switch ($i){
                                                    case 1: 
                                                    $day = "01";
                                                    break;

                                                    case 2: 
                                                    $day = "02";
                                                    break;

                                                    case 3: 
                                                    $day = "03";
                                                    break;

                                                    case 4: 
                                                    $day = "04";
                                                    break;

                                                    case 5: 
                                                    $day = "05";
                                                    break;

                                                    case 6: 
                                                    $day = "06";
                                                    break;

                                                    case 7: 
                                                    $day = "07";
                                                    break;

                                                    case 8: 
                                                    $day = "08";
                                                    break;

                                                    case 9: 
                                                    $day = "09";
                                                    break;

                                                    case $i: 
                                                    $day = $i;
                                                    break;

                                                }
                                                $date = $year->name."-".$month."-".$day;
                                                    $day = substr(date( 'l', strtotime( $month . '/' . $i ) ), 0, 3);

                                                    $price = "SELECT price_adult from rate_plan where date= '$date' and rate_range_id = $row->id";
                                                    $adult = Yii::$app->db->createCommand($price)->queryScalar();
                                                    $price_adult = empty($adult) ? "0" : $adult;

                                                    $price_child = "SELECT price_child from rate_plan where date= '$date' and rate_range_id = $row->id";


                                                    $child = Yii::$app->db->createCommand($price_child)->queryScalar();
                                                    $price_child = empty($child) ? "0" : $child;

                                                    echo "<td class= '<?= $day ;?>'>".$price_adult."</td>";
                                                    echo "<td class= '<?= $day ;?>'>".$price_child."</td>";
                                                    
                                                }
                                             ?>
                                    </tr>
                                <?php
                            }
                            
                         ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
 
$this->registerJs('
var controller_id = "rate-plan";
        $("#select_page_size").change(function(){
            var page_size = $("#select_page_size").val();
            var url = window.location.pathname;
                window.location.replace(url+"?r="+controller_id+"/index&page_size="+page_size);
        });


        $(document).on("click","#modalButton",function () { 
            $("#overlay").css("display", "block");
            $("#res-result").load($(this).attr("value"), function(res){ 
                $(this).html("");
                $("#modal").modal("show")
                $("#modalContent").html(res)
                $("#overlay").css("display", "none");
            })

        });

        $(document).on("click","#modalButtonView",function () { 
            $("#overlay").css("display", "block");
            $("#res-result").load($(this).attr("value"), function(res){ 
                $(this).html("");
                $("#modal").modal("show")
                $("#modalContent").html(res)
                $("#overlay").css("display", "none");
            })
        });

        $(document).on("click","#modalButtonUpdate",function () { 
            $("#overlay").css("display", "block");
            $("#res-result").load($(this).attr("value"), function(res){ 
                $(this).html("");
                $("#modal").modal("show")
                $("#modalContent").html(res)
                $("#overlay").css("display", "none");
            })
        });

    ');

?>
