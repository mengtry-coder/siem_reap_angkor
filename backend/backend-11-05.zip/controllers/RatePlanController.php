<?php

namespace backend\controllers;

use Yii;
use backend\models\RatePlan;
use backend\models\RatePlanSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Cookie;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use backend\models\RateRange;
/**
 * RatePlanController implements the CRUD actions for RatePlan model.
 */
class RatePlanController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all RatePlan models.
     * @return mixed
     */
    public function actionIndex()
    {
        $current_page = Yii::$app->controller->id."-index";
        $this->view->params['current_page'] = $current_page;
        
        $searchModel = new RatePlanSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        
        $total_items = $dataProvider->getTotalCount();

        $page_size = array_values( Yii::$app->params['page_size'])[0];
        $page_size_cookie = $current_page.'_page_size';
        if(isset($_REQUEST["page_size"])){
            if(intval($_REQUEST["page_size"])>0){
                $page_size = intval($_REQUEST["page_size"]);
                $set_cookies = Yii::$app->response->cookies;
                $set_cookies->add(new Cookie([
                'name' => $page_size_cookie,
                'value' => $page_size,
                'expire' => time() + (86400 * 3),
                ]));
            }
        } else {
            $get_cookies = Yii::$app->request->cookies;
            if ($get_cookies->has($page_size_cookie)) {
                $page_size = $get_cookies->getValue($page_size_cookie);
            }
        }

        $page = 0;
        $page_cookie = $current_page.'_page';
        if(isset($_REQUEST["page"])){
            if(intval($_REQUEST["page"])>0){
                $page = intval($_REQUEST["page"])-1;
                $set_cookies = Yii::$app->response->cookies;
                $set_cookies->add(new Cookie([
                'name' => $page_cookie,
                'value' => $page,
                'expire' => time() + (86400 * 3),
                ]));
            }
        } else {
            $get_cookies = Yii::$app->request->cookies;
            if ($get_cookies->has($page_cookie)) {
                $page = $get_cookies->getValue($page_cookie);
            }
        }
        $max_page = ceil($total_items / $page_size);

        $decrease_page = 0;
        while($page + 1 > $max_page){
            $page=$page-1;
            $decrease_page = 1;
        }
        if($decrease_page==1){
            $set_cookies = Yii::$app->response->cookies;
            $set_cookies->add(new Cookie([
            'name' => $page_cookie,
            'value' => $page,
            'expire' => time() + (86400 * 3),
            ]));
        }

        $dataProvider->pagination->pageSize = $page_size;
        $dataProvider->pagination->page = $page;

        return $this->render('index', [
            'page_size' => $page_size,
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single RatePlan model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->renderAjax('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new RatePlan model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate($month, $id, $year)
    {
        $get_tour_id = $id;
        $rate_set_up_id = ArrayHelper::map(\backend\models\RatePlanSetup::find()
                    ->where(['id' => $get_tour_id])
                    ->all(), 'id', function($model){return $model->name;});

        $model = new RatePlan();

        $model->created_date =  date('Y-m-d H:i:s');
        $created_date =  date('Y-m-d H:i:s');
        $created_by = Yii::$app->user->getId(); 
        $model->created_by = Yii::$app->user->getId(); 
        if ($model->load(Yii::$app->request->post())){
            $model->status = 1;
            $company_id = $_SESSION['company_id'];
            $from_date = $model->from_date;
            $to_date = $model->to_date;


            //===Start Compare value and sent to rate detail
            Yii::$app->db->createCommand("DELETE from rate_plan
            where date BETWEEN '$from_date' AND '$to_date' AND rate_set_up_id = $get_tour_id")->execute();
            //====start get value form input
            $from_person = Yii::$app->request->post('from');
            $to_people = Yii::$app->request->post('to');
            $cost_adult = Yii::$app->request->post('cost_adult');
            $cost_child = Yii::$app->request->post('cost_child');
            $mark_up_adult = Yii::$app->request->post('mark_up_adult');
            $mark_up_child = Yii::$app->request->post('mark_up_child');
            $mark_up_type = Yii::$app->request->post('mark_up_type');
            $price_adult = Yii::$app->request->post('price_adult');
            $price_child = Yii::$app->request->post('price_child');
            //====end get value form input

            //===Start save to rate range
            $str_range= "";
            if (!empty($from_person)) {
                Yii::$app->db->createCommand("DELETE from rate_range
            where month = $month and rate_set_up_id = $id")->execute();
                 Yii::$app->db->createCommand("DELETE from rate_plan
            where date BETWEEN '$from_date' AND '$to_date' AND rate_set_up_id = $id")->execute();
                foreach ($from_person as $key => $value) {
                    $model_rate_range = new RateRange();
                    $model_rate_range->rate_set_up_id = $get_tour_id;
                    $model_rate_range->month = $month;
                    $model_rate_range->year = $year;
                    $model_rate_range->from_person = $from_person[$key];
                    $model_rate_range->to_people = $to_people[$key];
                    if ($model_rate_range->save()) {
                        $rate_range_id = $model_rate_range->id;
                        for ($i=$model->from_date; $i <= $model->to_date; $i++) 
                        {
                            $model_rate_plan = new RatePlan();
                            $model_rate_plan->rate_range_id = $rate_range_id;
                            $model_rate_plan->date = $i;
                            $model_rate_plan->rate_set_up_id = $get_tour_id;
                            $model_rate_plan->cost_adult = $cost_adult[$key];
                            $model_rate_plan->cost_child = $cost_child[$key];
                            $model_rate_plan->mark_up_adult = $mark_up_adult[$key];
                            $model_rate_plan->mark_up_child = $mark_up_child[$key];
                            $model_rate_plan->mark_up_type = $mark_up_type[$key];
                            $model_rate_plan->price_adult = $price_adult[$key];
                            $model_rate_plan->price_child = $price_child[$key];
                            $model_rate_plan->company_id = $company_id;
                            $model_rate_plan->created_date = $created_date;
                            $model_rate_plan->created_by = $created_by;
                            $model_rate_plan->save();
                        }
                    }else{
                        echo "Not save";
                        exit();
                    }
                }
            }
           Yii::$app->session->setFlash('success', "Saved successful");
                    return $this->redirect('index.php?r=rate-plan/index');

        }
        return $this->render('create', [
            'model' => $model,
            'rate_set_up_id' => $rate_set_up_id,
            'month' => $month,
            'year' => $year,
        ]);
       
    }

    /**
     * Updates an existing RatePlan model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionUpdate($id)
    {
        $this -> layout = 'blankLayout';

        $model = $this->findModel($id);

        $model->updated_date =  date('Y-m-d H:i:s');
        $model->updated_by = Yii::$app->user->getId(); 
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success', "Saved successful");
            return $this->redirect(Yii::$app->request->referrer);
        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }

    /**
     * Deletes an existing RatePlan model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the RatePlan model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return RatePlan the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = RatePlan::findOne($id)) !== null) {
            return $model;
        }

        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
