<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm; 
use yii\helpers\ArrayHelper; 
use kartik\select2\Select2;
use backend\models\TourItem;

/* @var $this yii\web\View */
/* @var $model backend\models\RatePlanSetup */
/* @var $form yii\widgets\ActiveForm */
$base_url = Yii::getAlias('@web');
$this->registerJsFile(
    '@web/plugins/ckeditor/ckeditor.js',
    ['depends' => [\yii\web\JqueryAsset::className()]]
);
$time_template = '
    {label}
    </br>
    <div class="input-group">
        <span style="width: 40px" class="input-group-addon">
            <i class="demo-pli-clock"></i>
        </span> 
        {input} 
    </div>
    {error}{hint}';

$validationUrl = ['rateplansetup/validation'];
if (!$model->isNewRecord){
$validationUrl['id'] = $model->id;
}
?>

<div class="rate-plan-setup-form">

    <?php $form = ActiveForm::begin([
        'id' => $model->formName(),
        'enableAjaxValidation' => false,
        'enableClientValidation' => true,
        'options' => ['enctype' => 'multipart/form-data'],
        'validationUrl' => $validationUrl
    ]); ?>

    <div class="row"> 
        <div class="col-md-12">
            <div class="col-md-4">
                <?=$form->field($model, 'name')->textInput(['maxlength' => true])?>
            </div>
            <div class="col-md-4">
                <?php
                    $tour_item_id = ArrayHelper::map(\backend\models\TourItem::find()
                    ->where(['id' => $_SESSION['tour_item_id']])
                    ->all(), 'id', function($model){return $model->name;});
                ?>
                <?= $form->field($model, 'tour_item_id')->widget(Select2::classname(), [
                        'data' => $tour_item_id,
                        'theme' => Select2::THEME_DEFAULT,
                        'language' => 'eg',
                        'pluginOptions' => [
                            'allowClear' => true
                        ],
                    ]);
                ?> 
            </div>
            <div class="col-md-4">
                <?php
                $model->starting_time = $model->isNewRecord ? '5:00' : $model->starting_time;
                 ?>
                <?= $form->field($model, 'starting_time', [
                    'template'=>$time_template,
                    'options' => ['placeholder' => 'Time'],
                    'inputOptions' => [
                        'value' => \Yii::$app->formatter->asTime($model->starting_time, 'php:h:i')]])->textInput(['class'=>'date_picker']) 
                ?>  
            </div>
            <div class="col-md-12">
                <?= $form->field($model, 'description')->textArea(['class'=>"editor_area"]) ?>
            </div>

            <div class= "col-md-6">
                <?php
                    $model->status = $model->isNewRecord ? 1 : $model->status;
                    echo $form->field($model, 'status')->radioList(['1' => 'Active', '0' => 'Inactive'], ['unselect' => false, 'default' => 1]);
                ?>
            </div>
        </div>
    </div>
    
    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<?php
$script = <<< JS
    var base_url = "$base_url";
    $('.editor_area').each(function(e){
        CKEDITOR.replace( this.id, { customConfig: base_url + '/plugins/ckeditor/config.js' });
    });
    $('#rateplansetup-starting_time').datetimepicker({
        timepicker: true,
        datepicker: false,
        format: 'H:i',
        hours24: true,
    });
    
JS;
$this->registerJS($script);
?>