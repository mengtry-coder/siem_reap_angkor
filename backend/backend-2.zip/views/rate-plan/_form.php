<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\select2\Select2;
use yii\helpers\ArrayHelper;
use backend\models\YearList;

/* @var $this yii\web\View */
/* @var $model backend\models\RatePlan */
/* @var $form yii\widgets\ActiveForm */
$base_url = Yii::getAlias('@web');
$base_color = "#2b3d51";
$year_name = YearList::find()->where(['id'=>$year])->one()->name;
$total_days = cal_days_in_month(CAL_GREGORIAN, $month, $year_name);

$this->registerJsFile(
    '@web/plugins/ckeditor/ckeditor.js',
    ['depends' => [\yii\web\JqueryAsset::className()]]
);

$validationUrl = ['rate-plan/validation'];
if (!$model->isNewRecord){
$validationUrl['id'] = $model->id;
}

$date_template = '{label}</br><div class="input-group">
            <span style="width: 50px;line-height: 0rem;padding: 9px;" class="input-group-addon"><i class="fa fa-calendar"></i></span> {input} </div>{error}{hint}';
?>

<div class="rate-plan-form">

    <?php $form = ActiveForm::begin([
        'id' => $model->formName(),
        'enableAjaxValidation' => false,
        'enableClientValidation' => true,
        'options' => ['enctype' => 'multipart/form-data'],
        'validationUrl' => $validationUrl
    ]); ?>

   <div class="row"> 
        <div class="col-md-12">
            <div class="col-md-4">
                <?= $form->field($model, 'rate_set_up_id')->widget(Select2::classname(), [
                        'data' => $rate_set_up_id,
                        'theme' => Select2::THEME_DEFAULT,
                        'language' => 'eg',
                        'pluginOptions' => [
                            'allowClear' => true,
                            'disabled' => true,
                        ],
                    ]);
                ?>
            </div>
            <div class="col-md-4">
                <?= $form->field($model, 'from_date', ['template'=>$date_template])->textInput(['readonly' => true, 'style'=>'background: #fff !important;']) ?>
            </div>
            <div class="col-md-4">
                <?= $form->field($model, 'to_date', ['template'=>$date_template])->textInput(['readonly' => true, 'style'=>'background: #fff !important;']) ?>
            </div>
        </div>

        <!-- Rate Detail section -->
        <div class="col-md-12">
            <div class="panel panel-bordered panel-dark" style="margin: 10px;">
                <div class="panel-heading" style="color: white; background-color: <?= $base_color ;?>; border-color: <?= $base_color ;?>;">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-1">
                                <p>From</p>
                            </div>
                            <div class="col-md-1">
                                <p>To</p>
                            </div>
                            <div class="col-md-1">
                                <p>Cost Adult</p>
                            </div>
                            <div class="col-md-1">
                                <p>Cost Child</p>
                            </div>
                            <div class="col-md-1">
                                <p>M-Up Adult</p>
                            </div>
                            <div class="col-md-1">
                                <p>M-Up Child</p>
                            </div>
                            <div class="col-md-2">
                                <p>M-Up Type</p>
                            </div>
                            <div class="col-md-1">
                                <p>Price Adult</p>
                            </div>
                            <div class="col-md-1">
                                <p>Price Child</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel-body calculate_item">

                    <!-- ===== start first add item====== -->
                    <?php 
                        if ($model->isNewRecord) {
                     ?>
                     <div class="row row_line" data-id= 1 id= "row_line_1" style="margin: 10px;">
                        <div class="col-md-1">
                            <input type="number" name="from[]" min="0" class="form-control from" data-id=1
                                id="from_1" />
                        </div>
                        <div class="col-md-1">
                            <input type="number" name="to[]" min="0" class="form-control to" data-id=1
                                id="to_1" />
                        </div>
                        <div class="col-md-1">
                            <input type="number" name="cost_adult[]" min="0" class="form-control to" data-id=1
                                id="cost_adult_1" />
                        </div>
                        <div class="col-md-1">
                            <input type="number" name="cost_child[]" min="0" class="form-control cost_child" data-id=1
                                id="cost_child_1" />
                        </div>
                        <div class="col-md-1">
                            <input type="number" name="mark_up_adult[]" min="0" class="form-control mark_up_adult" data-id=1
                                id="mark_up_adult_1" />
                        </div>
                        <div class="col-md-1">
                            <input type="number" name="mark_up_child[]" min="0" class="form-control to" data-id=1
                                id="mark_up_child_1" />
                        </div>
                        <div class="col-md-2">
                            <select class="form-control mark_up_type" name="mark_up_type[]" data-id=1
                                id="mark_up_type_1">
                                <option value="1">amount</option>
                                <option value="2">%</option>
                            </select>
                        </div>
                        <div class="col-md-1">
                            <input type="float" name="price_adult[]" min="0" class="form-control price_adult" data-id=1
                                id="price_adult_1" />
                        </div>
                        <div class="col-md-1">
                            <input type="float" name="price_child[]" min="0" class="form-control price_child" data-id=1
                                id="price_child_1" />
                        </div>
                        <div class="col-md-1"></div>
                        <div class="col-md-1">
                            <i id=  "btn-add-rate" style="color: <?=$base_color; ?>; font-size: 40px; cursor: pointer;" class="ion-plus-circled add_more"></i>
                        </div>
                    </div>
                    <?php
                        }else{
                            $data_i = 0;
                            foreach ($model_rate_detail as $key => $value) {
                                $data_i++
                           ?>
                            <div class="row row_line" data-id= "<?= $data_i; ?>" id= "row_line_<?= $data_i; ?>" style="margin: 10px;">
                                <div class="col-md-1">
                                    <input type="number" name="from[]" min="0" value= "<?= $value->from_person ;?>" class="form-control from" data-id="<?= $data_i ;?>"
                                        id="from_1" />
                                </div>
                                <div class="col-md-1">
                                    <input type="number" name="to[]" min="0" value= "<?= $value->to_people ;?>" class="form-control to" data-id="<?= $data_i ;?>"
                                        id="to_1" />
                                </div>
                                <div class="col-md-1">
                                    <input type="number" name="cost_adult[]" min="0" value= "<?= $value->cost_adult ;?>" class="form-control to" data-id="<?= $data_i ;?>"
                                        id="cost_adult_1" />
                                </div>
                                <div class="col-md-1">
                                    <input type="number" name="cost_child[]" min="0" value= "<?= $value->cost_child ;?>" class="form-control cost_child" data-id="<?= $data_i ;?>"
                                        id="cost_child_1" />
                                </div>
                                <div class="col-md-1">
                                    <input type="number" name="mark_up_adult[]" min="0" value= "<?= $value->mark_up_adult ;?>" class="form-control mark_up_adult" data-id="<?= $data_i ;?>"
                                        id="mark_up_adult_1" />
                                </div>
                                <div class="col-md-1">
                                    <input type="number" name="mark_up_child[]" min="0" value= "<?= $value->mark_up_child ;?>" class="form-control to" data-id="<?= $data_i ;?>"
                                        id="mark_up_child_1" />
                                </div>
                                <div class="col-md-2">
                                    <select class="form-control mark_up_type" name="mark_up_type[]" data-id="<?= $data_i ;?>"
                                        id="mark_up_type_1">
                                        <option value="1">amount</option>
                                        <option value="2">%</option>
                                    </select>
                                </div>
                                <div class="col-md-1">
                                    <input type="float" name="price_adult[]" min="0" value= "<?= $value->price_adult ;?>" class="form-control price_adult" data-id="<?= $data_i ;?>"
                                        id="price_adult_1" />
                                </div>
                                <div class="col-md-1">
                                    <input type="float" name="price_child[]" min="0" value= "<?= $value->price_child ;?>" class="form-control price_child" data-id="<?= $data_i ;?>"
                                        id="price_child_1" />
                                </div>
                                <div class="col-md-1"></div>
                                <div class="col-md-1">
                                    <i id=  "btn-add-rate" style="color: <?= $data_i == 1 ? $base_color : "red" ;?>; font-size: 40px; cursor: pointer;" class="<?= $data_i == 1 ? "ion-plus-circled add_more" : "ion-minus-circled btn_remove" ;?>"></i>
                                </div>
                            </div>

                           <?php
                            }
                        }
                     ?>
                    <!-- ===== end first add item====== -->
                </div>
            </div>
        </div>
    </div>
    <div class="form-group" style="margin: 10px;">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success']) ?>
    </div>
    <?php ActiveForm::end(); ?>
</div>
<?php 
    
 ?>